// Copyright (c) 2012 Google Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#ifndef _MT
#error
#endif

#ifndef _DEBUG
#error
#endif

#ifdef _DLL
#error
#endif

int main() {
  return 0;
}
