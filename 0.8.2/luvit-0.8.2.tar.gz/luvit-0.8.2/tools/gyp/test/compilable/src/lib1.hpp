#ifndef _lib1_hpp
#define _lib1_hpp

extern void lib1_function(void);

#endif
