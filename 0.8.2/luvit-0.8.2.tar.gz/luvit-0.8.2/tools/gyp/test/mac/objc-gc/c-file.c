void c_fun() {}
