#ifndef LIB_VECTOR
#define LIB_VECTOR

#include "lua.h"
#include "lauxlib.h"

LUALIB_API int luaopen_vector (lua_State *L);

#endif
