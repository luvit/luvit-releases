#include <stdio.h>

int main() {
  printf("Hello from main1.cc\n");
  return 0;
}
