#include <stdio.h>

void subdir2_func(void)
{
  printf("Hello %s from subdir2/func.c\n", PROG);
}
