p({
  local_lib = require('./local_lib'),
  filename = __filename,
  dirname = __dirname
})

