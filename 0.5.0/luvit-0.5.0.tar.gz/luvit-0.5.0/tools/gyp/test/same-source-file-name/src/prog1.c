#include <stdio.h>

extern void func(void);

int main(int argc, char *argv[])
{
  printf("Hello from prog1.c\n");
  func();
  /*
   * Uncomment to test same-named files in different directories,
   * which Visual Studio doesn't support.
  subdir1_func();
  subdir2_func();
   */
  return 0;
}
