/* Copyright (c) 2011 Google Inc. All rights reserved.
 * Use of this source code is governed by a BSD-style license that can be
 * found in the LICENSE file.
 */

#ifndef A_H_
#define A_H_

#include "a/generated.h"

int funcA();

#endif  // A_H_
