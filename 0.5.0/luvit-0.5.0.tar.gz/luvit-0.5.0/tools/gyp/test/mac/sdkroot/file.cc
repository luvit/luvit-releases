#include <map>
using std::map;

int main() {
}
