From bogus2.c
