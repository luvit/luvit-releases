#include <stdio.h>

int main() {
  printf("Hello from main2.cc\n");
  return 0;
}
