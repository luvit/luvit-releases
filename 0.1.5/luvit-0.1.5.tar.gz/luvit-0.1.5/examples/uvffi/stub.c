#include "uv.h"
#include "http_parser.h"
// Convert this to a single header with:
// gcc -I /home/tim/luvit/deps/uv/include -I /home/tim/luvit/deps/http-parser -E stub.c | grep -v '^#' > ffi_uv.h

