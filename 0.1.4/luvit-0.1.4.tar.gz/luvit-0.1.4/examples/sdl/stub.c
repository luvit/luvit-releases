#include <SDL.h>
#include <SDL_ttf.h>
#include <SDL_image.h>
#include <SDL_mixer.h>

#include <SDL_gfxBlitFunc.h>
#include <SDL_gfxPrimitives.h>
//#include <SDL_gfxPrimitives_font.h>
#include <SDL_imageFilter.h>
#include <SDL_rotozoom.h>
// Convert this to a single header with:
// gcc -I /usr/include/SDL -E stub.c | grep -v '^#' > ffi_SDL.h

