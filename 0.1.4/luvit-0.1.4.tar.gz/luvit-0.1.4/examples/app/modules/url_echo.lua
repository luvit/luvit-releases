return function(req, res, continue)
  res:finish(req.url .. "\n")
end

