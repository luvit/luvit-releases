return {
  answer =42,
  filename = __filename,
  dirname = __dirname
}
